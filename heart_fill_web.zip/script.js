let fill = document.getElementById("fill");
let fillBtn = document.getElementById("fillBtn");
let pop = document.getElementById("popbtn");
let tada = document.getElementById("tadabtn");

let percent = 0;

fillBtn.addEventListener("click", () => {
    if (percent < 100) {
        percent += 10;
        fill.style.height = percent + "%";
        pop.play();
    } else {
        tada.play();
    }
});
